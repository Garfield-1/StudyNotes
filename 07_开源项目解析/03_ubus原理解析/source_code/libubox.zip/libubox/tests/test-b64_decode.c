#include "utils.h"

int main()
{
	b64_decode("Zg==", NULL, 2);
	return 0;
}
