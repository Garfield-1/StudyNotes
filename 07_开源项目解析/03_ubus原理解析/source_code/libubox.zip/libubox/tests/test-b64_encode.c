#include "utils.h"

int main()
{
	b64_encode("foo", 3, NULL, 2);
	return 0;
}
